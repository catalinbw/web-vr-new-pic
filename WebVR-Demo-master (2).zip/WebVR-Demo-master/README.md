# A Web VR demo

This simple example of web VR uses the [A-Frame Web VR framework](https://aframe.io/). 

[https://haddersbadders.github.io/WebVR-Demo/](https://haddersbadders.github.io/WebVR-Demo/)
